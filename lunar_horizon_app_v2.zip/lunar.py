import math
from datetime import datetime, timezone
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

LUNAR_RADIUS_KM = 1737.4

def julian_date(dt: datetime) -> float:
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    else:
        dt = dt.astimezone(timezone.utc)
    year = dt.year
    month = dt.month
    day = dt.day + (dt.hour + dt.minute / 60.0 + dt.second / 3600.0) / 24.0
    if month <= 2:
        year -= 1
        month += 12
    a = year // 100
    b = 2 - a + (a // 4)
    return int(365.25 * (year + 4716)) + int(30.6001 * (month + 1)) + day + b - 1524.5

def compute_ephemeris(lat_deg: float, lon_deg: float, dt_str: str):
    try:
        dt = datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
    except Exception:
        dt = datetime.now(timezone.utc)

    jd = julian_date(dt)
    d = jd - 2451545.0  # Days since J2000.0

    # Lunar orbital parameters (approximate analytical model)
    # Mean longitude of Moon (deg) and synodic phase
    sun_ecl_lon = (280.460 + 0.9856474 * d) % 360.0
    moon_mean_lon = (218.316 + 13.176396 * d) % 360.0
    sun_subsolar_lon = (sun_ecl_lon - moon_mean_lon + 180.0) % 360.0
    if sun_subsolar_lon > 180.0:
        sun_subsolar_lon -= 360.0
    sun_subsolar_lat = 1.54 * math.sin(math.radians(moon_mean_lon - 125.04))

    # Earth libration (optical libration in longitude & latitude)
    earth_sub_lon = 6.29 * math.sin(math.radians(134.963 + 13.064993 * d))
    earth_sub_lat = 5.13 * math.sin(math.radians(93.272 + 13.229350 * d))

    def alt_az(target_lat, target_lon):
        lat1 = math.radians(lat_deg)
        lat2 = math.radians(target_lat)
        dlon = math.radians(target_lon - lon_deg)

        sin_alt = math.sin(lat1) * math.sin(lat2) + math.cos(lat1) * math.cos(lat2) * math.cos(dlon)
        sin_alt = max(-1.0, min(1.0, sin_alt))
        alt = math.degrees(math.asin(sin_alt))

        y = math.sin(dlon) * math.cos(lat2)
        x = math.cos(lat1) * math.sin(lat2) - math.sin(lat1) * math.cos(lat2) * math.cos(dlon)
        az = (math.degrees(math.atan2(y, x)) + 360.0) % 360.0
        return round(alt, 2), round(az, 2)

    sun_alt, sun_az = alt_az(sun_subsolar_lat, sun_subsolar_lon)
    earth_alt, earth_az = alt_az(earth_sub_lat, earth_sub_lon)

    return {
        "julian_date": round(jd, 5),
        "sun": {"altitude_deg": sun_alt, "azimuth_deg": sun_az},
        "earth": {"altitude_deg": earth_alt, "azimuth_deg": earth_az},
    }

def generate_dem_patch(lat_deg: float, lon_deg: float, grid_size: int = 64, span_km: float = 20.0):
    """Generates a deterministic synthetic LOLA-style elevation patch (meters) around (lat, lon)."""
    half = grid_size // 2
    step_km = span_km / grid_size
    heights = []
    # Deterministic craters based on coordinates
    seed = math.sin(lat_deg * 12.9898 + lon_deg * 78.233) * 43758.5453
    craters = []
    for k in range(12):
        s1 = abs(math.sin(seed + k * 1.7))
        s2 = abs(math.cos(seed + k * 2.3))
        s3 = abs(math.sin(seed + k * 3.1))
        cx = (s1 - 0.5) * span_km * 0.85
        cy = (s2 - 0.5) * span_km * 0.85
        cr = 0.6 + s3 * 3.2
        cd = cr * 140.0
        craters.append((cx, cy, cr, cd))

    for j in range(grid_size):
        row = []
        y = (j - half) * step_km
        for i in range(grid_size):
            x = (i - half) * step_km
            # Gentle regional slope + undulating highlands
            h = (
                45.0 * math.sin(0.25 * x + math.radians(lon_deg))
                + 35.0 * math.cos(0.22 * y + math.radians(lat_deg))
                + 12.0 * math.sin(0.8 * x - 0.6 * y)
            )
            for cx, cy, cr, cd in craters:
                dist = math.hypot(x - cx, y - cy)
                if dist < cr:
                    # Bowl profile
                    norm = dist / cr
                    h -= cd * (1.0 - norm * norm)
                elif dist < cr * 1.25:
                    # Raised ejecta rim
                    rim = 1.0 - abs(dist - cr * 1.08) / (cr * 0.17)
                    if rim > 0:
                        h += cd * 0.18 * rim
            row.append(round(h, 2))
        heights.append(row)

    # 360-degree horizon elevation profile sampled around site center
    horizon = []
    for az in range(0, 360, 2):
        rad = math.radians(az)
        max_elev = -5.0
        for r_idx in range(2, half):
            dist_km = r_idx * step_km
            gx = int(round(half + (dist_km * math.sin(rad)) / step_km))
            gy = int(round(half - (dist_km * math.cos(rad)) / step_km))
            if 0 <= gx < grid_size and 0 <= gy < grid_size:
                dh = heights[gy][gx] - heights[half][half]
                elev_deg = math.degrees(math.atan2(dh, dist_km * 1000.0))
                if elev_deg > max_elev:
                    max_elev = elev_deg
        horizon.append({"azimuth": az, "elevation": round(max_elev, 2)})

    return {
        "grid_size": grid_size,
        "span_km": span_km,
        "center_elevation_m": heights[half][half],
        "heights_m": heights,
        "horizon_profile": horizon,
    }

@app.route("/api/simulate", methods=["POST"])
def simulate():
    data = request.get_json(force=True, silent=True) or {}
    lat = float(data.get("lat", 0.6741))
    lon = float(data.get("lon", 23.4730))
    dt_str = data.get("datetime", datetime.now(timezone.utc).isoformat())

    ephem = compute_ephemeris(lat, lon, dt_str)
    terrain = generate_dem_patch(lat, lon)

    return jsonify({
        "status": "ok",
        "coordinates": {"lat": lat, "lon": lon},
        "datetime": dt_str,
        "ephemeris": ephem,
        "terrain": terrain,
    })

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
