"""
Lunar Horizon Simulator - Web Server & Astronomical Engine
Integra horizon.py, ephemeris.py e lunar.py con l'interfaccia web HTML/Three.js/Plotly.
"""

import json
import math
import os
from datetime import datetime, timedelta, timezone

import numpy as np
import plotly.graph_objects as go
from flask import Flask, jsonify, render_template, request
from plotly.colors import sample_colorscale
from plotly.utils import PlotlyJSONEncoder

from ephemeris import (
    RAGGIO_SOLE_GRADI,
    SCALA_LUCE,
    direzione_enu,
    distanze_di_marcia,
    get_lunar_ephemeris,
    griglia_locale,
    illuminazione,
    in_scala_colori,
)
from horizon import (
    R_LUNA,
    SITI,
    USGS_LOLA_118M_URL,
    calcola_orizzonte,
    carica_ritaglio,
    scarica_ritaglio,
    terra_media,
)

app = Flask(__name__)


def build_horizon_figure(nome, az, piani, dist_km, lat, lon, h_oss, quota0, sun_az, sun_el, earth_az, earth_el):
    """Costruisce la figura Plotly del profilo dell'orizzonte a 360° con Sole e Terra."""
    orizzonte = piani[-1][1]
    y_min = math.floor(min(float(orizzonte.min()), -1.0, sun_el - 3.0) - 2.0)
    y_max = math.ceil(max(float(orizzonte.max()), 1.0, sun_el + 5.0, earth_el + 6.0) + 4.0)

    x3 = np.concatenate([az - 360.0, az, az + 360.0])
    tre = lambda v: np.concatenate([v, v, v])

    lim_km = np.array([p[0] for p in piani])
    t = (np.log(lim_km) - np.log(lim_km[0])) / (np.log(lim_km[-1]) - np.log(lim_km[0]))
    colori = sample_colorscale("Magma", [float(0.90 - 0.68 * v) for v in t])

    fig = go.Figure()
    for k in range(len(piani) - 1, -1, -1):
        fig.add_trace(go.Scatter(
            x=x3, y=np.full(x3.shape, y_min), mode="lines",
            line=dict(width=0), hoverinfo="skip", showlegend=False
        ))
        fig.add_trace(go.Scatter(
            x=x3, y=tre(piani[k][1]), mode="lines", fill="tonexty", fillcolor=colori[k],
            line=dict(color="rgba(0,0,0,0.45)", width=0.7),
            hoverinfo="skip", showlegend=False,
        ))

    # Linea dell'orizzonte
    fig.add_trace(go.Scatter(
        x=x3, y=tre(orizzonte), mode="lines", line=dict(color="#ffffff", width=1.8),
        name="Lunar Horizon", customdata=np.stack([tre(az), tre(dist_km)], axis=-1),
        hovertemplate=(
            "Azimuth: %{customdata[0]:.1f}°<br>"
            "Horizon Elev: %{y:.2f}°<br>"
            "Ridge Distance: %{customdata[1]:.1f} km<extra></extra>"
        ),
    ))

    # Linea 0° orizzontale locale
    fig.add_hline(y=0, line=dict(color="#94a3b8", width=1, dash="dot"))

    # Posizione del Sole (da JPL Horizons)
    fig.add_trace(go.Scatter(
        x=[sun_az - 360.0, sun_az, sun_az + 360.0],
        y=[sun_el] * 3,
        mode="markers+text",
        marker=dict(size=16, color="#fbbf24", line=dict(color="#fef3c7", width=2)),
        text=["☀ Sun"] * 3,
        textposition="top center",
        textfont=dict(color="#fbbf24", size=12),
        name="Sun (JPL Horizons)",
        hovertemplate=f"<b>Sun</b><br>Azimuth: {sun_az:.2f}°<br>Elevation: {sun_el:+.2f}°<extra></extra>",
    ))

    # Posizione della Terra (da JPL Horizons / terra_media)
    if earth_el > -15.0:
        fig.add_trace(go.Scatter(
            x=[earth_az - 360.0, earth_az, earth_az + 360.0],
            y=[earth_el] * 3,
            mode="markers+text",
            marker=dict(size=18, color="#38bdf8", line=dict(color="#e0f2fe", width=2)),
            text=["🌍 Earth"] * 3,
            textposition="top center",
            textfont=dict(color="#38bdf8", size=12),
            name="Earth (JPL Horizons)",
            hovertemplate=f"<b>Earth</b><br>Azimuth: {earth_az:.2f}°<br>Elevation: {earth_el:+.2f}°<extra></extra>",
        ))

    nomi = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]
    tick = np.arange(-360, 721, 15)
    etichette = [f"{nomi[int(tk % 360) // 45]} {int(tk % 360)}°" if tk % 45 == 0 else f"{int(tk % 360)}°" for tk in tick]
    centro = sun_az if sun_el > -10 else (earth_az if earth_el > -10 else 0.0)

    fig.update_layout(
        title=dict(
            text=f"<b>360° Horizon Profile — {nome}</b> <span style='font-size:11px;color:#94a3b8'>(Drag horizontally to pan 360°)</span>",
            x=0.01, y=0.97, font=dict(size=14)
        ),
        template="plotly_dark",
        paper_bgcolor="#020617",
        plot_bgcolor="#020617",
        dragmode="pan",
        hovermode="closest",
        margin=dict(l=55, r=25, t=48, b=45),
        xaxis=dict(
            range=[centro - 75, centro + 75],
            tickvals=tick, ticktext=etichette,
            showgrid=True, gridcolor="#1e293b", zeroline=False,
            title="Azimuth (°)"
        ),
        yaxis=dict(
            range=[y_min, y_max],
            fixedrange=True,
            gridcolor="#1e293b", zeroline=False,
            title="Elevation (°)"
        ),
        legend=dict(orientation="h", y=1.08, x=0.55, font=dict(size=11)),
    )
    return json.loads(json.dumps(fig, cls=PlotlyJSONEncoder))


def build_terrain_figure(nome, x_km, y_km, z_km, colori, sun_az, sun_el, perc_illum):
    """Costruisce la superficie 3D locale con illuminazione e ombre (da ephemeris.py / lunar.py)."""
    centro = len(x_km) // 2
    z_centro = float(np.nan_to_num(z_km[centro, centro]))
    lato_km = float(x_km[-1] - x_km[0])
    s = direzione_enu(sun_az, sun_el) * (0.35 * lato_km)
    colore_sole = "#ffd60a" if sun_el > -RAGGIO_SOLE_GRADI else "#64748b"

    fig = go.Figure(data=[
        go.Surface(
            x=x_km, y=y_km, z=z_km,
            surfacecolor=colori, cmin=0, cmax=255, colorscale=SCALA_LUCE,
            colorbar=dict(
                title=dict(text="Light", font=dict(size=11)), thickness=12, len=0.65,
                tickvals=[0, 64, 160, 255], ticktext=["Shadow", "Grazing", "Mid", "Full"],
            ),
            lighting=dict(ambient=0.8, diffuse=0.25, specular=0.0, roughness=1.0, fresnel=0.0),
            contours=dict(x=dict(highlight=False), y=dict(highlight=False), z=dict(highlight=False)),
            hovertemplate="E-W: %{x:.1f} km<br>S-N: %{y:.1f} km<br>Rel. Elev: %{z:.2f} km<extra></extra>",
        ),
        go.Scatter3d(
            x=[0.0, s[0]], y=[0.0, s[1]], z=[z_centro, z_centro + s[2]],
            mode="lines+markers+text",
            line=dict(color=colore_sole, width=6),
            marker=dict(size=[3, 8], color=colore_sole),
            text=["", "Sun"], textposition="top center", textfont=dict(color=colore_sole, size=12),
            showlegend=False,
        )
    ])

    fig.update_layout(
        title=dict(
            text=f"<b>{nome}</b> — Local DEM Illumination ({perc_illum:.1f}% lit)",
            x=0.02, y=0.96, font=dict(size=13)
        ),
        template="plotly_dark",
        paper_bgcolor="#020617",
        margin=dict(l=0, r=0, b=0, t=40),
        scene=dict(
            xaxis_title="West → East (km)",
            yaxis_title="South → North (km)",
            zaxis_title="Elevation (km)",
            xaxis_showspikes=False, yaxis_showspikes=False, zaxis_showspikes=False,
            aspectmode="data",
            camera=dict(eye=dict(x=1.25, y=-1.25, z=0.85)),
        ),
    )
    return json.loads(json.dumps(fig, cls=PlotlyJSONEncoder))


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/sites", methods=["GET"])
def api_sites():
    return jsonify(SITI)


@app.route("/api/simulate", methods=["POST"])
def api_simulate():
    try:
        payload = request.get_json(force=True)
        nome = payload.get("name", "Custom Lunar Site")
        lat = float(payload.get("lat", -43.31))
        lon = ((float(payload.get("lon", -11.36)) + 180.0) % 360.0) - 180.0
        date_str = payload.get("date") or datetime.now(timezone.utc).strftime("%Y-%m-%d")
        time_str = payload.get("time") or "12:00"

        dt_start = datetime.strptime(f"{date_str} {time_str}", "%Y-%m-%d %H:%M").replace(tzinfo=timezone.utc)
        dt_stop = dt_start + timedelta(hours=1)
        start_fmt = dt_start.strftime("%Y-%m-%d %H:%M")
        stop_fmt = dt_stop.strftime("%Y-%m-%d %H:%M")

        slug = "".join(c if c.isalnum() else "_" for c in nome.lower()).strip("_") or "site"
        raggio_km = 150.0
        raggio_m = raggio_km * 1000.0

        # 1. Scarica/carica ritaglio DEM LOLA
        file_tif = scarica_ritaglio(USGS_LOLA_118M_URL, slug, lat, lon, raggio_m)
        dem, transform, crs, passo = carica_ritaglio(file_tif)

        # 2. Calcola profilo orizzonte a 360° (horizon.py)
        az, piani, dist_km, quota0 = calcola_orizzonte(
            dem, transform, crs, lat, lon, h_oss=2.0, raggio_m=raggio_m, passo_az=1.0, passo_d=passo
        )
        orizzonte = piani[-1][1]

        # 3. Effemeridi JPL Horizons per Sole ('10') e Terra ('399') (ephemeris.py)
        alt_km = quota0 / 1000.0
        sun_eph = get_lunar_ephemeris("10", lat, lon, alt_km, start_fmt, stop_fmt, "1 h")
        _, sun_az, sun_el = sun_eph[0]

        try:
            earth_eph = get_lunar_ephemeris("399", lat, lon, alt_km, start_fmt, stop_fmt, "1 h")
            _, earth_az, earth_el = earth_eph[0]
        except Exception:
            earth_az, earth_el = terra_media(lat, lon)

        # Interpola elevazione dell'orizzonte all'azimut di Sole e Terra
        sun_hor = float(np.interp(sun_az % 360.0, az, orizzonte))
        earth_hor = float(np.interp(earth_az % 360.0, az, orizzonte))

        # 4. Calcola griglia locale 3D e illuminazione solare (ephemeris.py)
        larghezza_km = 60.0
        punti = 121
        semilato_m = larghezza_km * 500.0
        passo_m = larghezza_km * 1000.0 / (punti - 1)
        coord, z_ext = griglia_locale(dem, transform, crs, lat, lon, raggio_m, passo_m)
        n_ext = (len(coord) - 1) // 2
        n_mezzo = (punti - 1) // 2
        i0, i1 = n_ext - n_mezzo, n_ext + n_mezzo + 1

        dz_dn, dz_de = np.gradient(z_ext, passo_m)
        normali = np.stack([-dz_de, -dz_dn, np.ones_like(z_ext)], axis=-1)[i0:i1, i0:i1]
        normali /= np.maximum(np.linalg.norm(normali, axis=-1, keepdims=True), 1e-9)
        normali = np.nan_to_num(normali)

        distanze = distanze_di_marcia(passo_m, math.hypot(semilato_m, semilato_m) + raggio_m)
        el_buio = -math.degrees(raggio_m / R_LUNA) - 2.0 * RAGGIO_SOLE_GRADI
        validi = ~np.isnan(z_ext[i0:i1, i0:i1])

        if sun_el < el_buio:
            luce = np.zeros(validi.shape)
        else:
            luce = illuminazione(z_ext, passo_m, n_ext, i0, i1, normali, sun_az, sun_el, distanze)

        perc_illum = 100.0 * float(np.mean(luce[validi] > 1e-3)) if validi.any() else 0.0
        z_mostrato = z_ext[i0:i1, i0:i1]
        quota_min = float(np.nanmin(z_mostrato))
        quota_max = float(np.nanmax(z_mostrato))
        relief_km = (quota_max - quota_min) / 1000.0
        x_km = coord[i0:i1] / 1000.0
        z_km = (z_mostrato - quota_min) / 1000.0
        colori = in_scala_colori(luce)

        horizon_fig = build_horizon_figure(
            nome, az, piani, dist_km, lat, lon, 2.0, quota0, sun_az, sun_el, earth_az, earth_el
        )
        terrain_fig = build_terrain_figure(
            nome, x_km, x_km, z_km, colori, sun_az, sun_el, perc_illum
        )

        return jsonify({
            "quota0_m": quota0,
            "relief_km": relief_km,
            "illuminated_pct": perc_illum,
            "horizon_min_deg": float(np.min(orizzonte)),
            "horizon_max_deg": float(np.max(orizzonte)),
            "sun": {
                "az": sun_az,
                "el": sun_el,
                "horizon_el": sun_hor,
                "visible": sun_el > sun_hor - RAGGIO_SOLE_GRADI,
            },
            "earth": {
                "az": earth_az,
                "el": earth_el,
                "horizon_el": earth_hor,
                "visible": earth_el > earth_hor,
            },
            "horizon_fig": horizon_fig,
            "terrain_fig": terrain_fig,
        })

    except Exception as exc:
        return jsonify({"error": str(exc)}), 500


if __name__ == "__main__":
    print("=== Lunar Horizon Simulator Server ===")
    print("Apri nel browser: http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=True)
