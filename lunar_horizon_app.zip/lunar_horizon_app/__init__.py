"""Lunar Horizon Simulator Python Package."""
__version__ = "0.2.0"
