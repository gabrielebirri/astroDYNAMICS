# Lunar Horizon Simulator (Pacchetto Python)

Applicazione web integrata che collega l'interfaccia interattiva 3D (`templates/index.html`) ai moduli scientifici Python:
- `horizon.py`: scarica la finestra dal DEM globale USGS LOLA (118 m) e calcola il profilo dell'orizzonte a 360°.
- `ephemeris.py`: interroga NASA JPL Horizons per ottenere azimut ed elevazione di Sole (`10`) e Terra (`399`) e calcola luce/ombra sul terreno.
- `lunar.py`: gestione e rendering topografico 3D dei siti lunari.
- `app.py`: server Flask che espone l'interfaccia web e l'endpoint `/api/simulate`.

## Installazione e Avvio

1. Estrai l'archivio ed entra nella cartella `lunar_horizon_app`:
   ```bash
   cd lunar_horizon_app
   pip install -r requirements.txt
   ```

2. Avvia il server locale:
   ```bash
   python app.py
   ```

3. Apri il browser su `http://127.0.0.1:5000`.
